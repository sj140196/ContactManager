import { Component } from '@angular/core';
import { IContact } from '../../models/IContact';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-contact-manager',
  standalone: false,
  templateUrl: './contact-manager.component.html',
  styleUrl: './contact-manager.component.css',
})
export class ContactManagerComponent {
  public loading: boolean = false;
  public contacts: IContact[] = [];
  public errorMessage: string | null = null;

  constructor(private contactService: ContactService) {}

  ngOnInit(): void {
    this.getAllContactsFromServer();
  }

  public getAllContactsFromServer(){
    this.loading = true;
    this.contactService.getAllContacts().subscribe(
      (data: IContact[]) => {
        this.contacts = data;
        this.loading = false;
      },
      (error) => {
        this.errorMessage = error;
        this.loading = false; //(see 1:05:00)
      }
    );
  }

  public deleteContact(contactId:any){
    if(contactId){
      this.contactService.deleteContact(contactId).subscribe((data)=>{
      this.getAllContactsFromServer();
      }, (error)=>{
        this.errorMessage=error;
      });
    }
  }
}
