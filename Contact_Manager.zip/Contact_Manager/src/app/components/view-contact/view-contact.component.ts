import { Component } from '@angular/core';
import { IContact } from '../../models/IContact';
import { ActivatedRoute, Params } from '@angular/router';
import { ContactService } from '../../services/contact.service';
import { IGroup } from '../../models/IGroup';

@Component({
  selector: 'app-view-contact',
  standalone: false,
  templateUrl: './view-contact.component.html',
  styleUrl: './view-contact.component.css',
})
export class ViewContactComponent {
  public contactId: string | null = null;
  public loading: boolean = false;
  public contact: IContact = {} as IContact;
  public errorMessage: string | null = null;
  public group:IGroup={} as IGroup;

  constructor(
    private activatedRoute: ActivatedRoute,
    private contactservice: ContactService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((param) => {
      this.contactId = param.get('contactId');
    });

    if (this.contactId) {
      this.loading = true;
      this.contactservice.getContact(this.contactId).subscribe({
        next: (data: IContact) => {
          this.contact = data;
          this.loading = false;
          this.contactservice.getGroup(data).subscribe((data)=>{
            this.group=data;
          });
        },
        error: (error: string | null) => {
          this.errorMessage = error;
          this.loading = false;
        },
        complete: () => {
          console.log('Data fetching completed.');
        }
      });
      
      this.loading = false;
    }
  }

  public isNotEmpty() {
    return Object.keys(this.contact).length > 0 && Object.keys(this.group).length > 0;;
  }
}
