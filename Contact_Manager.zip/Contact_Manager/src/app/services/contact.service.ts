import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { IContact } from '../models/IContact';
import { IGroup } from '../models/IGroup';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private  serverUrl:string="http://localhost:9000";

  constructor(private httpClient:HttpClient){}
  
  public getAllContacts():Observable<IContact[]>{
    let dataUrl:string=`${this.serverUrl}/contacts`;
    return this.httpClient.get<IContact[]>(dataUrl).pipe(catchError(this.handleError));
    }
    
    
    public createContact(contact:IContact):Observable<IContact>{
    let dataUrl:string=`${this.serverUrl}/contacts`;
    return this.httpClient.post<IContact>(dataUrl,contact).pipe(catchError(this.handleError));
    }
    
    public updateContact(contact:IContact, contactId:string):Observable<IContact>{
    let dataUrl:string=`${this.serverUrl}/contacts/${contactId}`;
    return this.httpClient.put<IContact>(dataUrl,contact).pipe(catchError(this.handleError));
    }
    
    public deleteContact( contactId:string):Observable<{}>{
    let dataUrl:string=`${this.serverUrl}/contacts/${contactId}`;
    return this.httpClient.delete<{}>(dataUrl).pipe(catchError(this.handleError));
    }
    
    public getAllGroups():Observable<IGroup[]>{
    let dataUrl:string=`${this.serverUrl}/groups`;
    return this.httpClient.get<IGroup[]>(dataUrl).pipe(catchError(this.handleError));
    }
    
    public getGroup(contact:IContact):Observable<IGroup>{
    let dataUrl:string = `${this.serverUrl}/groups/${contact.groupId}`;
    return this.httpClient.get<IGroup>(dataUrl).pipe(catchError(this.handleError));
    }
    
    public getContact(contactId:string):Observable<IContact>{
    let dataUrl:string = `${this.serverUrl}/contacts/${contactId}`;
    return this.httpClient.get<IContact>(dataUrl).pipe(catchError(this.handleError));
    }
    
  private handleError(error: HttpErrorResponse) {
      let errorMessage = '';
  
      if (error.error instanceof ErrorEvent) {
        // Client-side or network error
        errorMessage = `Client-side error: ${error.error.message}`;
      } else {
        // Server-side error
        errorMessage = `Server-side error: ${error.status} - ${error.message}`;
      }
  
      // Optionally log the error to the console or send to a logging service
      console.error(errorMessage);
  
      // Return an observable with a user-facing error message
      return throwError(() => new Error('Something went wrong; please try again later.'));
    }
}
