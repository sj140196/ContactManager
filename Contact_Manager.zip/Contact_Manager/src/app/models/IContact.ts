export interface IContact{
    id?:string;
    name:string;
    email:string;
    mobile:string;
    photo:string;
    company:string;
    title:string;
    groupId:string;
}